# Algorytm wczytujący długość boku kwadratu i wypisujący jego pole oraz obwód.

print "Podaj długość boku kwadratu: "
a = gets.to_i

print "Pole powierzchni kwartatu to: "
puts a*a

print "Obwód kwadratu: "
puts 4*a
