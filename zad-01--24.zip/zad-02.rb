# Algorytm wczytujący liczbę dni, a następnie liczący i wypisujący liczbę sekund
# w tych dniach (np. dla 7 wypisze 10080).


print "Podaj liczbę dni: "
days = gets.to_i

print "Ilość sekund w podanych dniach: "
puts days*24*60*60
